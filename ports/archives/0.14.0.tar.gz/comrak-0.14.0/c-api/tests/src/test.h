#ifndef TESTS_H
#define TESTS_H

#include "../../include/comrak.h"

void test_comrak_basic();

void test_commonmark_extension_options();
void test_commonmark_parse_options();
void test_commonmark_render_options();

#endif // TESTS_H
